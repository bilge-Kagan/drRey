/**
 * dr_success page, javascript
 */

$(document).on('turbolinks:load', function(){

});
