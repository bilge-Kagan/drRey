/**
 * mail_page javascript
 */


$(document).on('turbolinks:load', function(){

});
